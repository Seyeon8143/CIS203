package edu.byuh.cis.cs203.tokens1.ui;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.res.Resources;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.SystemClock;
import android.util.Log;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Toast;

import edu.byuh.cis.cs203.tokens1.Timer;
import edu.byuh.cis.cs203.tokens1.logic.GameBoard;
import edu.byuh.cis.cs203.tokens1.logic.GameMode;
import edu.byuh.cis.cs203.tokens1.logic.Player;

/**
 * The GameView class runs the user interface of our app.
 * All drawing is initiated here; all touch events are
 * handled here.
 */
public class GameView extends View implements TickListener {

	/**
	 * This class pumps out "timer" events at
	 * regular intervals, so we can do animation.
	 */

	private Grid grid;
	private boolean firstRun;
	private GuiButton currentButton;
	private GuiButton[] buttons;
	private List<GuiToken> tokens;
	private GameBoard engine;
	private Timer tim;
	private GuiToken.GridPosition gridPosition;
	private List<GuiToken> neighbours;
	private GuiToken gridToken;
	private int playero = 0;
	private int playerx = 0;
	private Paint bananaScore;
	private Paint manggoScore;
	private GameMode player;


	/**
	 * Basic constructor. Initializes all fields that don't
	 * directly rely on the screen resolution being known.
	 *
	 * @param context The Activity class that created the View
	 */
	public GameView(Context context) {
		super(context);
		firstRun = true;
		buttons = new GuiButton[10];
		tokens = new ArrayList<>();
		engine = new GameBoard();
		neighbours = new ArrayList<>();
		bananaScore = new Paint();
		bananaScore.setColor(Color.BLACK);
		manggoScore = new Paint();
		manggoScore.setColor(Color.BLACK);
		player = GameMode.ONE_PLAYER;

		tim = Timer.factory();

		//tim = new Timer();
	}

	/**
	 * Draws the grid, buttons, and tokens.
	 *
	 * @param c The Canvas object, supplied by the system.
	 */
	@Override
	public void onDraw(Canvas c) {
		super.onDraw(c);
		Log.d("cs203","ondraw!!!");
		c.drawColor(Color.WHITE);
		if (firstRun) {
			//tim = new Timer();
			init();
			Timer.factory().subscribe(this);
			firstRun = false;//여기에 false 를 하니까 yes 를 눌러도 플레이어 선택 창 안나옴 근데 재시작을 안함

			AlertDialog.Builder ab = new AlertDialog.Builder(getContext());
			ab.setTitle("GameMode");
			ab.setMessage("please choose GameMode");
			ab.setCancelable(false);
			//각자 다른 플레이어를 선택하면 그에따른 모드를 실행하는법?
			ab.setPositiveButton("one player", new DialogInterface.OnClickListener() {
				@Override
				public void onClick(DialogInterface dialogInterface, int i) {
					player = GameMode.ONE_PLAYER;
					dialogInterface.dismiss();
				}
			});
			ab.setNegativeButton("two player", new DialogInterface.OnClickListener() {
				@Override
				public void onClick(DialogInterface dialogInterface, int i) {
					player = GameMode.TWO_PLAYER;
					dialogInterface.dismiss();
				}
			});
			AlertDialog box = ab.create();
			box.show();

		}

		grid.draw(c);
		//when the tokens are invisible make them unregister
		for (GuiToken t : tokens) {
			if (t.isInvisible((getHeight()))) {
				tokens.remove(t);
				t.setFalling(false);
				Timer.factory().unsubscribe(t);
				break; // catch concurrentmodification error

			} else {
				t.draw(c);
			}
		}
		for (GuiButton b : buttons) {
			b.draw(c);
		}


		bananaScore.setTextSize(48f);
		c.drawText("Banana:" + playero, 50, 0.87f * 100, bananaScore);
		manggoScore.setTextSize(48f);
		c.drawText("Manggo: " + playerx, 400, 0.87f * 100, manggoScore);
		Log.d("cs203", "ondraw call agin");

	}

	private void init() {
		float w = getWidth();
		float h = getHeight();
		float unit = w / 16f;
		float gridX = unit * 2.5f;
		float cellSize = unit * 2.3f;
		float gridY = unit * 9;
		float buttonTop = gridY - cellSize;
		float buttonLeft = gridX - cellSize;
		grid = new Grid(gridX, gridY, cellSize);
		buttons[0] = new GuiButton('1', this, buttonLeft + cellSize * 1, buttonTop, cellSize);
		buttons[1] = new GuiButton('2', this, buttonLeft + cellSize * 2, buttonTop, cellSize);
		buttons[2] = new GuiButton('3', this, buttonLeft + cellSize * 3, buttonTop, cellSize);
		buttons[3] = new GuiButton('4', this, buttonLeft + cellSize * 4, buttonTop, cellSize);
		buttons[4] = new GuiButton('5', this, buttonLeft + cellSize * 5, buttonTop, cellSize);
		buttons[5] = new GuiButton('A', this, buttonLeft, buttonTop + cellSize * 1, cellSize);
		buttons[6] = new GuiButton('B', this, buttonLeft, buttonTop + cellSize * 2, cellSize);
		buttons[7] = new GuiButton('C', this, buttonLeft, buttonTop + cellSize * 3, cellSize);
		buttons[8] = new GuiButton('D', this, buttonLeft, buttonTop + cellSize * 4, cellSize);
		buttons[9] = new GuiButton('E', this, buttonLeft, buttonTop + cellSize * 5, cellSize);
	}

	/**
	 * this method help to find currently tokens position
	 *
	 * @param row
	 * @param col
	 * @return
	 */
	private GuiToken getTokenAt(char row, char col) {
		for (GuiToken t : tokens) {
			if (t.gridPosition.row == row && t.gridPosition.col == col) {
				return t;
			}
		}
		return null;
	}


	/**
	 * Handles all touch events.
	 *
	 * @param m an object that contains the (x,y) coordinates
	 *          of the touch event (among other things)
	 * @return true, always. (Just like the Church!)
	 */
	@Override
	public boolean onTouchEvent(MotionEvent m) {

		//ignore touch events if the View is not fully initialized
		//if (grid == null || firstRun) return true;
		if (GuiToken.moverfind() == true) return true;

		float x = m.getX();
		float y = m.getY();
		if (m.getAction() == MotionEvent.ACTION_DOWN) {

			currentButton = null;
			for (GuiButton b : buttons) {
				if (b.contains(x, y)) {
					currentButton = b;
					b.press();
					break;
				}
			}

			//show a helpful hint if the user taps inside the grid
			if (currentButton == null) {
				Toast t = Toast.makeText(getContext(),
						"To play, touch one of the buttons next to the grid.",
						Toast.LENGTH_LONG);
				t.setGravity(Gravity.TOP, 0, 0);
				t.show();
			}

		} else if (m.getAction() == MotionEvent.ACTION_MOVE) {
			boolean touchingAButton = false;
			for (GuiButton b : buttons) {
				if (b.contains(x, y)) {
					touchingAButton = true;
					if (currentButton != null && b != currentButton) {
						currentButton.release();
						currentButton = null;
						break;
					}
				}
			}
			if (!touchingAButton) {
				unselectAllButtons();
			}
		} else if (m.getAction() == MotionEvent.ACTION_UP) {
			for (GuiButton b : buttons) {
				if (b.contains(x, y)) {

					if (b == currentButton) {
						currentButton.release();
						GuiToken tok;
						ArrayList<GuiToken> neighbors = new ArrayList<>();
						//if currenButton is top button when you instanciate new token set it position to the row and column it should be in
						if (b.isTopButton()) {
							//b.getLabel is col of the button the user pressed.
							tok = new GuiToken(engine.getCurrentPlayer(), this, currentButton, getResources(), b.getLabel(), 'A');
							Timer.factory().subscribe(tok);
							//tokens.add(tok);
							//find the token position
							for (char topLabel = 'A'; topLabel <= 'E'; topLabel++) {
								GuiToken search = getTokenAt(topLabel, b.getLabel());
								if (search != null) {
									neighbors.add(search);
								} else {
									break;
								}

							}
							tokens.add(tok);
							for (GuiToken t : neighbors) {
								t.moveDown();
								int position = (int) t.gridPosition.row + 1;
								t.setDestination((char) position, t.gridPosition.col);

							}
						} else {

							tok = new GuiToken(engine.getCurrentPlayer(), this, currentButton, getResources(), '1', b.getLabel());
							Timer.factory().subscribe(tok);
							//tokens.add(tok);
							for (char leftLabel = '1'; leftLabel <= '5'; leftLabel++) {
								GuiToken search = getTokenAt(b.getLabel(), leftLabel);
								if (search != null) {
									neighbors.add(search);
								} else {
									break;
								}
							}
							tokens.add(tok);
							for (GuiToken t : neighbors) {
								t.moveRight();//첫번째 토큰하나를 움직
								//one cell lower than it was before
								int position = (int) t.gridPosition.col + 1;//두번째 토큰들이 이동할 좌표
								t.setDestination(t.gridPosition.row, (char) position);
							}
						}

						engine.submitMove(currentButton.getLabel());

						//neighbours.add(tok);
					}
				}
			}
			currentButton = null;
		}
		invalidate();
		return true;
	}


	private void unselectAllButtons() {
		for (GuiButton b : buttons) {
			b.release();
		}
	}


	private void reset(){
		tokens.clear();
		engine.clear();
		Timer.factory().deregisterAll();
		//firstRun = true;
		Timer.factory().subscribe(this);

		Timer.factory().restart();//timer paused false


	}

//위너를 리턴하는 창을 보여줌
	@Override
	public void onTick() {


		//현재 결과값과 같지않은 경우에만 우승자를 리턴함
		if (engine.checkForWin() != Player.BLANK && GuiToken.moverfind() == false) {
			//prevent multitime show
			Timer.factory().pause();
			AlertDialog.Builder ab = new AlertDialog.Builder(getContext());
			ab.setTitle("Game over");
			ab.setMessage("winner is " + engine.checkForWin().toString());
			ab.setCancelable(false);
			//anonymous class
			ab.setPositiveButton("yes", new DialogInterface.OnClickListener() {
				@Override
				public void onClick(DialogInterface dialogInterface, int i) {
					reset();
					invalidate();

					//tim.register(this);

				}
			});
			//게임이 다시시작될때 게임뷰를 register 하려니까 에러뜸}
			//using lamda expression
			ab.setNegativeButton("no", (d, which) -> {
				((Activity) getContext()).finish();
			});
			AlertDialog box = ab.create();
			box.show();
			if (engine.checkForWin() == Player.O) {

				playero++;

			} else if (engine.checkForWin() == Player.X) {

				playerx++;

			} else {
				Log.d("tie", "tie");
			}


		} else {
			if (player == GameMode.ONE_PLAYER) {
				if (engine.getCurrentPlayer() == Player.O) {
					post(new Runnable() {
						@Override
						public void run() {
							int random = new Random().nextInt(9);
							int buttonY = (int) buttons[random].getBounds().top;
							int buttonX = (int) buttons[random].getBounds().left;

							//counting time
							long downTime = SystemClock.uptimeMillis();
							long eventTime = SystemClock.uptimeMillis() + 100;
							int metaState = 0;
							MotionEvent motionEvent = MotionEvent.obtain(
									downTime,
									eventTime,
									MotionEvent.ACTION_DOWN,
									buttonX,
									buttonY,
									metaState
							);
							MotionEvent motionUpEvent = MotionEvent.obtain(
									downTime,
									eventTime,
									MotionEvent.ACTION_UP,
									buttonX,
									buttonY,
									metaState
							);
							dispatchTouchEvent(motionEvent);
							dispatchTouchEvent(motionUpEvent);
						}
					});
				}
			}

			//invalidate();
		}
		invalidate();

	}
		}



