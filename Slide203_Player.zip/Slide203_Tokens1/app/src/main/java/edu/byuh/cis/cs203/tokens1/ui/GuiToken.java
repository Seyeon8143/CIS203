package edu.byuh.cis.cs203.tokens1.ui;

import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.PointF;
import android.graphics.RectF;
import android.view.View;

import edu.byuh.cis.cs203.tokens1.R;
import edu.byuh.cis.cs203.tokens1.logic.Player;

/**
 * Represents a single X or O on the grid.
 * It is the graphical analog to the Player enum.
 */
public class GuiToken implements TickListener {



	private Player player;
	private RectF bounds;
	private PointF velocity;
	private PointF destination;
	private float tolerance;
	private Bitmap image;
	public GridPosition gridPosition;
	private static int movers;
	private boolean falling = false;
	private float height;


	@Override
	public void onTick() {
		move();
	}

	public class GridPosition {


		public char col;
		public char row;

//		public GridPosition(char topLabel,char leftLabel){
//			this.col = topLabel;
//			this.row = leftLabel;lt
//		}
	}



	/**
	 * Create a new GuiToken object
	 * @param p The Player (X or O) who created the token
	 * @param parent which button was tapped to create the token
	 * @param res the Resources object (used for loading image)
	 */
	public GuiToken(Player p,View view, GuiButton parent, Resources res,char topLabel,char leftLabel) {
		this.bounds = new RectF(parent.getBounds());
		velocity = new PointF();
		destination = new PointF();
		tolerance = bounds.height()/10f;
		player = p;
		movers = 0;
		if (player == Player.X) {
			image = BitmapFactory.decodeResource(res, R.drawable.player_x);
		} else {
			image = BitmapFactory.decodeResource(res, R.drawable.player_o);
		}
		image = Bitmap.createScaledBitmap(image, (int)bounds.width(), (int)bounds.height(), true);
		if (parent.isTopButton()) {
			moveDown();
		} else {
			moveRight();
		}
		gridPosition = new GridPosition();
		gridPosition.row = leftLabel;
		gridPosition.col = topLabel;
		height = view.getHeight();


		//gridPosition = new GridPosition(topLabel, leftLabel);
	}

	/**
	 * Draw the token at the correct location, using the correct
	 * image (X or O)
	 * @param c The Canvas object supplied by onDraw
	 */
	public void draw(Canvas c) {
		c.drawBitmap(image, bounds.left, bounds.top, null);
	}

	/**
	 * Move the token by its current velocity.
	 * Stop when it reaches its destination location.
	 */
	public void move() {

			float dx = destination.x - bounds.left;
			float dy = destination.y - bounds.top;

			if (falling) {
				velocity.y = velocity.y*2;

				bounds.offset(0,80f);//의미가 뭔지 .. ?


			} else {
				if (velocity.x != 0 || velocity.y != 0) {
					if (PointF.length(dx, dy) < tolerance) {//오차값 설정
					bounds.offsetTo(destination.x, destination.y);//
					velocity.set(0, 0);
					movers = -1;
					//when the tokens out of the grid
					if (gridPosition.row > 'E' || gridPosition.col > '5') {
						falling = true;
						setGoal(bounds.left, height);

						velocity.set(0,1);//무엇을의미 ?
					}
				} else {
					bounds.offset(velocity.x, velocity.y);//토큰이 다시 움직일때 의미 ?
					//movers = +1;
				}
			}

		}

	}

	public boolean isInvisible(float viewHeight){
		if(bounds.top > viewHeight){
			return true;
		}else{
			return false;
		}
	}
	public void setFalling(boolean isfalling){
		this.falling = isfalling;
	}
	/**
	 * Helper method for tokens created by the top row of buttons
	 */
	public void moveDown() {
		setGoal(bounds.left, bounds.top+bounds.height());
	}

	/**
	 * Helper method for tokens created by the left column of buttons
	 */
	public void moveRight() {
		setGoal(bounds.left+bounds.width(), bounds.top);
	}

	/**
	 * Is animation currently happening?
	 * @return true if the token is currently moving (i.e. has a non-zero velocity); false otherwise.
	 */
	public boolean isMoving() {
		return (velocity.x > 0 || velocity.y > 0);
	}

	/**
	 * Assign a destination location to the token
	 * @param x the X coordinate where the token should stop
	 * @param y the X coordinate where the token should stop
	 *
	 */
	public void setGoal(float x, float y) {
		movers++;
		destination.set(x,y);//위치를 지정
		float dx = destination.x - bounds.left;
		float dy = destination.y - bounds.top;
		velocity.x = dx/11f;//속도를 지정
		velocity.y = dy/11f;

	}

	/**
	 * this method help to set tokens destination
	 * @param row currently gridPosition row
	 * @param col currently gridPosition col
	 */
	public void setDestination(char row,char col){
		gridPosition.row = row;
		gridPosition.col = col;

	}

	public static boolean moverfind(){
		if(movers>0){
			return true;
		}else {
			return false;
		}
	}

}







