package edu.byuh.cis.cs203.tokens1.ui;

public interface TickListener {
    void onTick();
}
