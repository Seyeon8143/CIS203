package edu.byuh.cis.cs203.tokens1.logic;

public enum GameMode {
    ONE_PLAYER,
    TWO_PLAYER,

}
