package edu.byuh.cis.cs203.tokens1;

import android.os.Handler;
import android.os.Message;

import java.util.ArrayList;
import java.util.List;

import edu.byuh.cis.cs203.tokens1.ui.GuiToken;
import edu.byuh.cis.cs203.tokens1.ui.TickListener;

public class Timer extends Handler {

    private List<TickListener> listeners;
    private boolean paused;
    private static Timer instance = new Timer();

    private Timer() {
        listeners = new ArrayList<>();
        handleMessage(obtainMessage());
    }

    public static Timer factory(){
        if(instance == null){
            instance = new Timer();

        }
        return instance;
    }


    public void subscribe(TickListener t) {
        listeners.add(t);
    }

    public void unsubscribe(TickListener t) {
        listeners.remove(t);
    }

    public void deregisterAll() {
        listeners.clear();
    }


    public void pause() {
        paused = true;
    }

    public void restart() {
        paused = false;
    }

    @Override
    public void handleMessage(Message m) {
        if (!paused) {
            for (TickListener t : listeners) {
                t.onTick();
            }
        }
        sendMessageDelayed(obtainMessage(), 100);
    }
}

